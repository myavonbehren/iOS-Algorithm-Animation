//
//  mvonbehr_hw1Tests.swift
//  mvonbehr-hw1Tests
//
//  Created by Mya Von Behren on 4/14/25.
//

import Testing
@testable import mvonbehr_hw1

struct mvonbehr_hw1Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
